
                  
                  <?php                   
                  foreach($slist as $row)
                  {
                  ?>
                    <tr>
                      <td class="snumber"><?=$row->surah_no;?></td>
                      <td><?=$row->surah_name;?></td>
                    </tr>
                 <?php                   
                  } ?>
                  